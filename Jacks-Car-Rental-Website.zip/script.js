function toggleMenu(){const n=document.getElementById('nav');n.style.display=n.style.display==='flex'?'none':'flex';n.style.position='absolute';n.style.top='76px';n.style.left='0';n.style.right='0';n.style.background='#f6f6f3';n.style.padding='20px';n.style.flexDirection='column';n.style.borderBottom='1px solid #ddd'}
function selectVehicle(v){document.getElementById('vehicle').value=v}
function fmt(d){return new Date(d+'T00:00:00').toLocaleDateString('en-PH',{month:'short',day:'numeric',year:'numeric'})}
function quickBook(e){e.preventDefault();document.getElementById('pickup').value=document.getElementById('qPickup').value;document.getElementById('return').value=document.getElementById('qReturn').value;document.getElementById('booking').scrollIntoView({behavior:'smooth'});}
function submitBooking(e){
 e.preventDefault();
 const name=document.getElementById('name').value.trim(),phone=document.getElementById('phone').value.trim(),vehicle=document.getElementById('vehicle').value,pickup=document.getElementById('pickup').value,ret=document.getElementById('return').value,msg=document.getElementById('message').value.trim();
 if(ret<pickup){document.getElementById('formStatus').textContent='Return date must be on or after the pick-up date.';return}
 const text=`Hi Jack’s Car Rental! I’d like to make a booking inquiry.\n\nName: ${name}\nMobile: ${phone}\nVehicle: ${vehicle}\nPick-up: ${fmt(pickup)}\nReturn: ${fmt(ret)}${msg?`\nMessage: ${msg}`:''}\n\nPlease let me know the availability and rental rate. Thank you!`;
 const status=document.getElementById('formStatus');
 navigator.clipboard?.writeText(text).catch(()=>{});
 status.innerHTML='Your booking message is ready. <a href="sms:+639684426426?body='+encodeURIComponent(text)+'"><b>Tap here to send by SMS</b></a> — or call <a href="tel:+639684426426"><b>09684426426</b></a>.';
}