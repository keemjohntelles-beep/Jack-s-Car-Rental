# Jack’s Car Rental Website

A responsive static website inspired by the rental storefront / operations style of the reference site.

## Business details used
- Jack’s Car Rental
- Urdaneta City, Pangasinan
- 09684426426
- Mitsubishi Xpander 2026
- Toyota Vios Grayish Blue
- Toyota Vios Super Red

## Run locally
Open `index.html` in a browser.

## Deploy
Upload the folder to Vercel, Netlify, GitHub Pages, or another static hosting service.
